import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import net from 'net';
import path from 'path';

async function startServer() {
  const app = express();
  const PORT = 3000;
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: '*',
    },
  });

  app.use(express.json());

  // API routes
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  // TCP Client management
  let tcpClient: net.Socket | null = null;
  let intervalId: NodeJS.Timeout | null = null;
  let frameNumber = 1;

  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    socket.on('start', (config) => {
      console.log('Start requested with config:', config);
      
      if (tcpClient) {
        tcpClient.destroy();
        tcpClient = null;
      }
      if (intervalId) {
        clearInterval(intervalId);
        intervalId = null;
      }

      frameNumber = 1;

      tcpClient = new net.Socket();
      
      tcpClient.connect(config.port, config.ip, () => {
        console.log('Connected to TCP server');
        socket.emit('status', { status: 'connected' });

        // Send immediately, then every 10 seconds
        sendPacket(config, socket);
        intervalId = setInterval(() => {
          sendPacket(config, socket);
        }, 10000);
      });

      tcpClient.on('data', (data) => {
        console.log('Received:', data.toString());
        socket.emit('log', { type: 'receive', data: data.toString() });
      });

      tcpClient.on('error', (err) => {
        console.error('TCP Error:', err);
        socket.emit('status', { status: 'error', message: err.message });
        stopClient();
      });

      tcpClient.on('close', () => {
        console.log('TCP Connection closed');
        socket.emit('status', { status: 'disconnected' });
        stopClient();
      });
    });

    socket.on('stop', () => {
      console.log('Stop requested');
      stopClient();
      socket.emit('status', { status: 'disconnected' });
    });

    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
      stopClient();
    });
  });

  function stopClient() {
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
    if (tcpClient) {
      tcpClient.destroy();
      tcpClient = null;
    }
  }

  function sendPacket(config: any, socket: any) {
    if (!tcpClient) return;

    const now = new Date();
    // UTC date: DDMMYYYY
    const date = String(now.getUTCDate()).padStart(2, '0') +
                 String(now.getUTCMonth() + 1).padStart(2, '0') +
                 now.getUTCFullYear();
    
    // UTC time: HHMMSS
    const time = String(now.getUTCHours()).padStart(2, '0') +
                 String(now.getUTCMinutes()).padStart(2, '0') +
                 String(now.getUTCSeconds()).padStart(2, '0');

    const lat = Math.abs(config.latitude).toFixed(8);
    const latDir = config.latitude >= 0 ? 'N' : 'S';
    
    const lon = Math.abs(config.longitude).toFixed(8);
    const lonDir = config.longitude >= 0 ? 'E' : 'W';

    const frameStr = String(frameNumber).padStart(6, '0');
    frameNumber++;

    const packet = `NRM,ROADRPA,1.3.4,NR,01,L,${config.imei},${config.vehicleNo},1,${date},${time},${lat},${latDir},${lon},${lonDir},0.0,0.00,0,0.0,0.00,0.00,airtel,1,1,20.2,4.2,0,C,21,404,10,009C,D1F3,11,009C,E098,10,009C,D1F4,10,009C,E09A,06,009C,D1F2,0000,00,10113,10113,${frameStr},0.000,-,-,-,-,1_1_5_5_0,A6CFAF75*`;

    try {
      tcpClient.write(packet);
      console.log('Sent:', packet);
      socket.emit('log', { type: 'send', data: packet });
    } catch (err: any) {
      console.error('Send error:', err);
      socket.emit('status', { status: 'error', message: err.message });
      stopClient();
    }
  }

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://trackfleet.in/index.php:${PORT}`);
  });
}

startServer();
