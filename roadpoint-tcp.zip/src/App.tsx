/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { Play, Square, MapPin, Activity, Server, FileText, AlertCircle } from 'lucide-react';

export default function App() {
  const [ip, setIp] = useState('127.0.0.1');
  const [port, setPort] = useState('8080');
  const [imei, setImei] = useState('862491073908590');
  const [vehicleNo, setVehicleNo] = useState('RJ01GC2496');
  const [latitude, setLatitude] = useState('28.51552540');
  const [longitude, setLongitude] = useState('77.28125390');
  
  const [status, setStatus] = useState<'disconnected' | 'connected' | 'error'>('disconnected');
  const [errorMessage, setErrorMessage] = useState('');
  const [logs, setLogs] = useState<{ time: string; type: 'send' | 'receive'; data: string }[]>([]);
  
  const socketRef = useRef<Socket | null>(null);
  const logsEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Connect to the Socket.IO server on the same origin
    const socket = io();
    socketRef.current = socket;

    socket.on('status', (data: { status: string; message?: string }) => {
      if (data.status === 'connected') {
        setStatus('connected');
        setErrorMessage('');
      } else if (data.status === 'disconnected') {
        setStatus('disconnected');
      } else if (data.status === 'error') {
        setStatus('error');
        setErrorMessage(data.message || 'Unknown error');
      }
    });

    socket.on('log', (data: { type: 'send' | 'receive'; data: string }) => {
      setLogs((prev) => [...prev, { time: new Date().toLocaleTimeString(), type: data.type, data: data.data }]);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  useEffect(() => {
    if (logsEndRef.current) {
      logsEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [logs]);

  const handleStart = () => {
    if (!socketRef.current) return;
    
    setLogs([]);
    setStatus('disconnected');
    setErrorMessage('');
    
    socketRef.current.emit('start', {
      ip,
      port: parseInt(port, 10),
      imei,
      vehicleNo,
      latitude: parseFloat(latitude),
      longitude: parseFloat(longitude),
    });
  };

  const handleStop = () => {
    if (!socketRef.current) return;
    socketRef.current.emit('stop');
  };

  const getLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLatitude(position.coords.latitude.toFixed(8));
          setLongitude(position.coords.longitude.toFixed(8));
        },
        (error) => {
          alert('Error getting location: ' + error.message);
        }
      );
    } else {
      alert('Geolocation is not supported by this browser.');
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 p-6 font-sans">
      <div className="max-w-5xl mx-auto space-y-6">
        
        <header className="flex items-center justify-between pb-4 border-b border-zinc-200">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 text-white rounded-xl">
              <Activity size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">ROADPOINT TCP Client</h1>
              <p className="text-sm text-zinc-500">Continuous Data Packet Transmitter</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${status === 'connected' ? 'bg-emerald-500 animate-pulse' : status === 'error' ? 'bg-red-500' : 'bg-zinc-300'}`}></div>
            <span className="text-sm font-medium uppercase tracking-wider text-zinc-600">
              {status}
            </span>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Configuration Panel */}
          <div className="lg:col-span-1 space-y-6">
            
            <div className="bg-white p-5 rounded-2xl shadow-sm border border-zinc-200 space-y-4">
              <div className="flex items-center gap-2 text-zinc-800 font-semibold pb-2 border-b border-zinc-100">
                <Server size={18} />
                <h2>Server Configuration</h2>
              </div>
              
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-zinc-500 mb-1 uppercase tracking-wider">TCP Server IP</label>
                  <input 
                    type="text" 
                    value={ip} 
                    onChange={(e) => setIp(e.target.value)}
                    className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-500 mb-1 uppercase tracking-wider">TCP Server Port</label>
                  <input 
                    type="number" 
                    value={port} 
                    onChange={(e) => setPort(e.target.value)}
                    className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl shadow-sm border border-zinc-200 space-y-4">
              <div className="flex items-center gap-2 text-zinc-800 font-semibold pb-2 border-b border-zinc-100">
                <FileText size={18} />
                <h2>Device Details</h2>
              </div>
              
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-zinc-500 mb-1 uppercase tracking-wider">IMEI Number</label>
                  <input 
                    type="text" 
                    value={imei} 
                    onChange={(e) => setImei(e.target.value)}
                    className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-500 mb-1 uppercase tracking-wider">Vehicle Number</label>
                  <input 
                    type="text" 
                    value={vehicleNo} 
                    onChange={(e) => setVehicleNo(e.target.value)}
                    className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
                  />
                </div>
              </div>
            </div>

            <div className="bg-white p-5 rounded-2xl shadow-sm border border-zinc-200 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-100">
                <div className="flex items-center gap-2 text-zinc-800 font-semibold">
                  <MapPin size={18} />
                  <h2>Location</h2>
                </div>
                <button 
                  onClick={getLocation}
                  className="text-xs bg-indigo-50 text-indigo-600 hover:bg-indigo-100 px-2 py-1 rounded-md font-medium transition-colors"
                >
                  Auto Pull
                </button>
              </div>
              
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-zinc-500 mb-1 uppercase tracking-wider">Latitude</label>
                  <input 
                    type="text" 
                    value={latitude} 
                    onChange={(e) => setLatitude(e.target.value)}
                    className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-500 mb-1 uppercase tracking-wider">Longitude</label>
                  <input 
                    type="text" 
                    value={longitude} 
                    onChange={(e) => setLongitude(e.target.value)}
                    className="w-full px-3 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-colors"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={handleStart}
                disabled={status === 'connected'}
                className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-600/50 disabled:cursor-not-allowed text-white py-3 px-4 rounded-xl font-medium transition-colors shadow-sm"
              >
                <Play size={18} fill="currentColor" />
                Start Sending
              </button>
              <button
                onClick={handleStop}
                disabled={status !== 'connected'}
                className="flex-1 flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-900 disabled:bg-zinc-800/50 disabled:cursor-not-allowed text-white py-3 px-4 rounded-xl font-medium transition-colors shadow-sm"
              >
                <Square size={18} fill="currentColor" />
                Stop
              </button>
            </div>

            {status === 'error' && (
              <div className="bg-red-50 text-red-600 p-4 rounded-xl text-sm flex items-start gap-3 border border-red-100">
                <AlertCircle size={18} className="shrink-0 mt-0.5" />
                <p>{errorMessage}</p>
              </div>
            )}

          </div>

          {/* Logs Panel */}
          <div className="lg:col-span-2 flex flex-col h-[600px] bg-zinc-900 rounded-2xl shadow-md overflow-hidden border border-zinc-800">
            <div className="bg-zinc-950 px-4 py-3 border-b border-zinc-800 flex items-center justify-between">
              <h2 className="text-zinc-300 font-mono text-sm uppercase tracking-wider">Transmission Logs</h2>
              <div className="text-xs text-zinc-500 font-mono">
                Interval: 10s
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-2">
              {logs.length === 0 ? (
                <div className="h-full flex items-center justify-center text-zinc-600 italic">
                  No logs yet. Click Start to begin transmission.
                </div>
              ) : (
                logs.map((log, index) => (
                  <div key={index} className="flex gap-3 items-start break-all">
                    <span className="text-zinc-500 shrink-0">[{log.time}]</span>
                    <span className={log.type === 'send' ? 'text-emerald-400' : 'text-blue-400'}>
                      {log.type === 'send' ? '→' : '←'}
                    </span>
                    <span className="text-zinc-300">{log.data}</span>
                  </div>
                ))
              )}
              <div ref={logsEndRef} />
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
